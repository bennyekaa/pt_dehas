<?php $__env->startSection('content'); ?>
    <div>
        <iframe src="<?php echo e($custom->url_web); ?>" height="700px" width="1400px"></iframe>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PT_DEHAS\resources\views/map/map.blade.php ENDPATH**/ ?>