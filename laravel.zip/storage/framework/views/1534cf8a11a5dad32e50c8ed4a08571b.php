<!DOCTYPE html>
<html>

<head>
    <title>PT Dehas Inframedia Karsa - User</title>
</head>

<body>

    <?php $__env->startSection('content'); ?>
        <div class="container-fluid" id="container-wrapper">
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h3 mb-0 text-gray-800">Data Titik Kumpul</h1>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <div class="card mb-4">
                        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                            <a class="btn btn-primary" href="/user/tambah" style="float: left;"> + Tambah Titik Kumpul</a>
                        </div>
                        <div class="table-responsive p-3">
                            <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                                <thead class="thead-light">
                                    <tr>
                                        <th>Kode Titik Kumpul</th>
                                        <th>Titik Kumpul Latitude</th>
                                        <th>Titik Kumpul Longitude</th>
                                        <th>Nama Titik Kumpul</th>
                                        <th>Nama Desa</th>
                                        <th>Nama Kecamatan</th>
                                        <th>Nama Kabupaten</th>
                                        <th>Jarak ke Titik Kumpul</th>
                                        <th>Dibuat Pada</th>
                                        <th>Dibuat Oleh</th>
                                        <th>Diupdate Pada</th>
                                        <th>Diupdate Oleh</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $i = 1;
                                    ?>
                                    <?php $__currentLoopData = $titikkumpul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($p->kode_tk); ?> </td>
                                            <td><?php echo e($p->tk_lat); ?> </td>
                                            <td><?php echo e($p->tk_long); ?> </td>
                                            <td><?php echo e($p->nama_titik_kumpul); ?> </td>
                                            <td><?php echo e($p->nama_desa); ?> </td>
                                            <td><?php echo e($p->nama_kecamatan); ?> </td>
                                            <td><?php echo e($p->nama_kabupaten); ?> </td>
                                            <td><?php echo e($p->jarak_ke_tk); ?> </td>
                                            <td><?php echo e($p->created_at); ?></td>
                                            <td><?php echo e($p->created_by); ?></td>
                                            <td><?php echo e($p->updated_at); ?></td>
                                            <td><?php echo e($p->updated_by); ?></td>
                                            <td>
                                                <div class="btn-group">
                                                    <a class="btn btn-warning" title="Edit"
                                                        href="/titikkumpul/edit/<?php echo e(encrypt($p->id_titik_kumpul)); ?>">
                                                        <i class="fa fa-edit"></i>
                                                    </a>
                                                    <a class="btn btn-danger alert_notif" title="Hapus"
                                                        href="/titikkumpul/hapus/<?php echo e($p->id_titik_kumpul); ?>">
                                                        <i class="fa fa-trash"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>


</body>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PT_DEHAS\resources\views/master/titikkumpul.blade.php ENDPATH**/ ?>