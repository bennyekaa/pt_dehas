<ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar">
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(url('/')); ?>">
        <div class="sidebar-brand-icon">
            <img src="<?php echo e(asset('assets/img/logo/pt_dehas.jpg')); ?>">
        </div>
        <div class="sidebar-brand-text mx-3">PT Dehas</div>
    </a>
    <hr class="sidebar-divider my-0">

    <?php if(session('role') == 0): ?>
    <li class="nav-item <?php echo e(Request::segment(1) == '/' ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('/')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('detailbendungan')); ?>">
            <i class="fas fa-fw fa-bookmark"></i>
            <span>Detail Bendungan</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(Request::segment(1) == 'map' ? 'active' : ''); ?>" href="<?php echo e(url('map')); ?>">
            <i class="fas fa-fw fa-map-marked"></i>
            <span>Kelola Maps</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseBootstrap" aria-expanded="true" aria-controls="collapseBootstrap">
            <i class="far fa-fw fa-window-maximize"></i>
            <span>Input Data Waduk</span>
        </a>
        <div id="collapseBootstrap" class="collapse" aria-labelledby="headingBootstrap" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Input Data Waduk</h6>
                <a class="collapse-item" href="<?php echo e(url('transaksi/mukaair/index')); ?>/<?php echo e(encrypt(session('role'))); ?>">Waduk Banjir</a>
                <a class="collapse-item" href="<?php echo e(url('transaksi/bocor/index')); ?>/<?php echo e(encrypt(session('role'))); ?>">Waduk Bocor</a>
            </div>
        </div>
    </li>
    <?php elseif(session('role') == 1): ?>
    <li class="nav-item <?php echo e(Request::segment(1) == '/' ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('/')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('detailbendungan')); ?>">
            <i class="fas fa-fw fa-bookmark"></i>
            <span>Detail Bendungan</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link <?php echo e(Request::segment(1) == 'map' ? 'active' : ''); ?>" href="<?php echo e(url('map')); ?>">
            <i class="fas fa-fw fa-map-marked"></i>
            <span>Kelola Maps</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('import')); ?>">
            <i class="fas fa-fw fa-file-import"></i>
            <span>Import</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseMaster" aria-expanded="true" aria-controls="collapseMaster">
            <i class="far fa-fw fa-window-maximize"></i>
            <span>Master</span>
        </a>
        <div id="collapseMaster" class="collapse" aria-labelledby="headingMaster" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Master</h6>
                <a class="collapse-item" href="<?php echo e(url('bendungan')); ?>">Bendungan</a>
                <a class="collapse-item" href="<?php echo e(url('desa')); ?>">Desa</a>
                <a class="collapse-item" href="<?php echo e(url('kategoribocor')); ?>">Kategori Bocor</a>
                <a class="collapse-item" href="<?php echo e(url('pengungsian')); ?>">Pengungsian</a>
                <a class="collapse-item" href="<?php echo e(url('statusbocor')); ?>">Status Bocor</a>
                <a class="collapse-item" href="<?php echo e(url('titikkumpul')); ?>">Titik Kumpul</a>
                <a class="collapse-item" href="<?php echo e(url('user')); ?>">User</a>
                <a class="collapse-item" href="<?php echo e(url('waduk')); ?>">Waduk</a>
                <a class="collapse-item" href="<?php echo e(url('web')); ?>">Website</a>
            </div>
    </li>

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTrans" aria-expanded="true" aria-controls="collapseTrans">
            <i class="fab fa-fw fa-wpforms"></i>
            <span>Transaksi</span>
        </a>
        <div id="collapseTrans" class="collapse" aria-labelledby="headingTrans" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Data Waduk</h6>
                <a class="collapse-item" href="<?php echo e(url('transaksi/mukaair/index')); ?>/<?php echo e(encrypt(session('role'))); ?>">Waduk Banjir</a>
                <a class="collapse-item" href="<?php echo e(url('transaksi/bocor/index')); ?>/<?php echo e(encrypt(session('role'))); ?>">Waduk Bocor</a>
            </div>
        </div>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('laporan')); ?>">
            <i class="fas fa-fw fa-book"></i>
            <span>Laporan</span>
        </a>
    </li>
    <?php elseif(session('role') == 5): ?>
    <li class="nav-item <?php echo e(Request::segment(1) == '/' ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('/')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('detailbendungan')); ?>">
            <i class="fas fa-fw fa-bookmark"></i>
            <span>Detail Bendungan</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(Request::segment(1) == 'map' ? 'active' : ''); ?>" href="<?php echo e(url('map')); ?>">
            <i class="fas fa-fw fa-map-marked"></i>
            <span>Kelola Maps</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseBootstrap" aria-expanded="true" aria-controls="collapseBootstrap">
            <i class="far fa-fw fa-window-maximize"></i>
            <span>Detail Data Waduk</span>
        </a>
        <div id="collapseBootstrap" class="collapse" aria-labelledby="headingBootstrap" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Detail Data Waduk</h6>
                <a class="collapse-item" href="<?php echo e(url('transaksi/mukaair/index')); ?>/<?php echo e(encrypt(session('role'))); ?>">Waduk Banjir</a>
                <a class="collapse-item" href="<?php echo e(url('transaksi/bocor/index')); ?>/<?php echo e(encrypt(session('role'))); ?>">Waduk Bocor</a>
            </div>
        </div>
    </li>
    <?php endif; ?>
    

    

    <hr class="sidebar-divider">
    <div class="version" id="version-ruangadmin"></div>
</ul><?php /**PATH C:\laragon\www\PT_DEHAS\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>