<!DOCTYPE html>
<html>

<head>
    <title>PT Dehas Inframedia Karsa - User</title>
</head>

<body>

    <?php $__env->startSection('content'); ?>
        <div class="container-fluid" id="container-wrapper">
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h3 mb-0 text-gray-800">Data Pengungsian</h1>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <div class="card mb-4">
                        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                            <a class="btn btn-primary" href="/pengungsian/tambah" style="float: left;"> + Tambah
                                Pengungsian</a>
                        </div>
                        <div class="table-responsive p-3">
                            <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                                <thead class="thead-light">
                                    <tr>
                                        <th>Kode Pengungsian</th>
                                        <th>Pengungsian Latitude</th>
                                        <th>Pengungsian Longitude</th>
                                        <th>Nama Pengungsian</th>
                                        <th>Nama Desa Pengungsian</th>
                                        <th>Nama Kecamatan Pengungsian</th>
                                        <th>Nama Kabupaten Pengungsian</th>
                                        <th>Jarak ke Pengungsian</th>
                                        <th>Dibuat Pada</th>
                                        <th>Dibuat Oleh</th>
                                        <th>Diupdate Pada</th>
                                        <th>Diupdate Oleh</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $i = 1;
                                    ?>
                                    <?php $__currentLoopData = $pengungsian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($p->kode_pengungsian); ?> </td>
                                            <td><?php echo e($p->pengungsian_lat); ?> </td>
                                            <td><?php echo e($p->pengungsian_long); ?> </td>
                                            <td><?php echo e($p->nama_pengungsian); ?> </td>
                                            <td><?php echo e($p->nama_desa_pengungsian); ?> </td>
                                            <td><?php echo e($p->nama_kecamatan_pengungsian); ?> </td>
                                            <td><?php echo e($p->nama_kabupaten_pengungsian); ?> </td>
                                            <td><?php echo e($p->jarak_pengungsian); ?> </td>
                                            <td><?php echo e($p->created_at); ?></td>
                                            <td><?php echo e($p->created_by); ?></td>
                                            <td><?php echo e($p->updated_at); ?></td>
                                            <td><?php echo e($p->updated_by); ?></td>
                                            <td>
                                                <div class="btn-group">
                                                    <a class="btn btn-warning" title="Edit"
                                                        href="/pengungsian/edit/<?php echo e(encrypt($p->id_pengungsian)); ?>">
                                                        <i class="fa fa-edit"></i>
                                                    </a>
                                                    <a class="btn btn-danger alert_notif" title="Hapus"
                                                        href="/pengungsian/hapus/<?php echo e($p->id_pengungsian); ?>">
                                                        <i class="fa fa-trash"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>


</body>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PT_DEHAS\resources\views/master/pengungsian.blade.php ENDPATH**/ ?>