<?php $__env->startSection('content'); ?>
<div class="container-fluid" id="container-wrapper">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Data Bocor</h1>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="card mb-4">
                <?php if(session('role') == 0): ?>
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <a class="btn btn-primary" href="<?php echo e(url('transaksi/bocor/tambah')); ?>" style="float: left;"> +
                        Input Data Waduk Bocor
                    </a>
                </div>
                <?php endif; ?>
                <div class="table-responsive p-3">
                    <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                        <thead class="thead-light">
                            <tr>
                                <th>#</th>
                                <th>Kategori</th>
                                <th>Status Bocor</th>
                                <th>keterangan</th>
                                <th>File</th>
                                <th>Dibuat Pada</th>
                                <th>Dibuat Oleh</th>
                                <th>Diupdate Pada</th>
                                <th>Diupdate Oleh</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $i = 1;
                            $file = 1;
                            ?>
                            <?php $__currentLoopData = $bocor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?> </td>
                                <td><?php echo e($item->statusbocor->kategoribocor->nama_kategori); ?> </td>
                                <td><?php echo e($item->statusbocor->nama_status); ?> </td>
                                <td><?php echo e($item->keterangan); ?> </td>
                                <td>file-upload <?php echo e($file++); ?> </td>
                                <td><?php echo e($item->created_at); ?></td>
                                <td><?php echo e($item->created_by); ?></td>
                                <td><?php echo e($item->updated_at); ?></td>
                                <td><?php echo e($item->updated_by); ?></td>
                                <td>
                                    <div class="btn-group">
                                        <?php if(session('role') == 0): ?>
                                        <a class="btn btn-primary" title="Kirim Ke Balai" href="<?php echo e(url('transaksi/bocor/kirim')); ?>/<?php echo e(encrypt($item->id_banjir_bocor)); ?>">
                                            <i class="fa fa-arrow-right"></i>
                                        </a>
                                        <a class="btn btn-danger alert_notif" id="notif" title="Hapus" href="<?php echo e(url('transaksi/bocor/hapus')); ?>/<?php echo e(encrypt($item->id_banjir_bocor)); ?>">
                                            <i class="fa fa-trash"></i>
                                        </a>
                                        <?php elseif(session('role') == 5): ?>
                                        <div class="dropdown">
                                            <a class="btn btn-primary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Kirim Pemberitahuan
                                            </a>
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                <a class="dropdown-item" href="#">Bupati</a>
                                                <a class="dropdown-item" href="#">BPPD</a>
                                                <a class="dropdown-item" href="#">PENDUDUK</a>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PT_DEHAS\resources\views/transaksi/bocor/index.blade.php ENDPATH**/ ?>