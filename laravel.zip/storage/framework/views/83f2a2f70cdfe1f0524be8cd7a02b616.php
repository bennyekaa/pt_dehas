<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Register')); ?></div>

                <div class="card-body">
                    <form action="<?php echo e(url('prosesbendungan')); ?>" method="post">

                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id_bendungan" value="<?php echo e($data->id_bendungan); ?>">
                        
                        <div class="row mb-3">
                            <label for="nama_bendungan" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Nama Bendungan')); ?></label>

                            <div class="col-md-6">
                                <input id="nama_bendungan" type="text" class="form-control <?php $__errorArgs = ['nama_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama_bendungan" value="<?php echo e($data->nama_bendungan); ?>" required autocomplete="name" autofocus>

                                <?php $__errorArgs = ['nama_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="lokasi_bendungan" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Lokasi Bendungan')); ?></label>

                            <div class="col-md-6">
                                <input id="lokasi_bendungan" type="text" class="form-control <?php $__errorArgs = ['lokasi_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="lokasi_bendungan" value="<?php echo e($data->lokasi_bendungan); ?>" required autocomplete="name" autofocus>

                                <?php $__errorArgs = ['lokasi_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="nama_sungai" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Nama Sungai')); ?></label>

                            <div class="col-md-6">
                                <input id="nama_sungai" type="text" class="form-control <?php $__errorArgs = ['nama_sungai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama_sungai" value="<?php echo e($data->nama_sungai); ?>" required autocomplete="email">

                                <?php $__errorArgs = ['nama_sungai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="koordinat_bendungan_x" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Koordinat Bendungan X')); ?></label>

                            <div class="col-md-6">
                                <input id="koordinat_bendungan_x" type="text" class="form-control <?php $__errorArgs = ['koordinat_bendungan_x'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="koordinat_bendungan_x" value="<?php echo e($data->koordinat_bendungan_x); ?>" required autocomplete="new-koordinat_bendungan_x">

                                <?php $__errorArgs = ['koordinat_bendungan_x'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="koordinat_bendungan_y" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Koordinat Bendungan Y')); ?></label>

                            <div class="col-md-6">
                                <input id="koordinat_bendungan_y" type="text" class="form-control <?php $__errorArgs = ['koordinat_bendungan_y'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="koordinat_bendungan_y" value="<?php echo e($data->koordinat_bendungan_y); ?>" required autocomplete="new-koordinat_bendungan_y">

                                <?php $__errorArgs = ['koordinat_bendungan_y'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="pengelola_bendungan" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Pengelola Bendungan')); ?></label>

                            <div class="col-md-6">
                                <input id="pengelola_bendungan" type="text" class="form-control <?php $__errorArgs = ['pengelola_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pengelola_bendungan" value="<?php echo e($data->pengelola_bendungan); ?>" required autocomplete="new-pengelola_bendungan">

                                <?php $__errorArgs = ['pengelola_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="telp_pengelola_bendungan" class="col-md-4 col-form-label text-md-end"><?php echo e(__('No Telp')); ?></label>

                            <div class="col-md-6">
                                <input id="telp_pengelola_bendungan" type="text" class="form-control <?php $__errorArgs = ['telp_pengelola_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="telp_pengelola_bendungan" value="<?php echo e($data->telp_pengelola_bendungan); ?>" required autocomplete="new-telp_pengelola_bendungan">
                                <?php $__errorArgs = ['telp_pengelola_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="alamat_pengelola_bendungan" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Alamat Pengelola Bendungan')); ?></label>

                            <div class="col-md-6">
                                <input id="alamat_pengelola_bendungan" type="text" class="form-control <?php $__errorArgs = ['alamat_pengelola_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="alamat_pengelola_bendungan" value="<?php echo e($data->alamat_pengelola_bendungan); ?>" required autocomplete="new-alamat_pengelola_bendungan">

                                <?php $__errorArgs = ['alamat_pengelola_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="type_tubuh_bendungan" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Tipe Tubuh Bendungan')); ?></label>

                            <div class="col-md-6">
                                <input id="type_tubuh_bendungan" type="text" class="form-control <?php $__errorArgs = ['type_tubuh_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="type_tubuh_bendungan" value="<?php echo e($data->type_tubuh_bendungan); ?>" required autocomplete="new-type_tubuh_bendungan">

                                <?php $__errorArgs = ['type_tubuh_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="panjang_puncak_tubuh_bendungan" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Panjang Puncak Tubuh Bendungan')); ?></label>

                            <div class="col-md-6">
                                <input id="panjang_puncak_tubuh_bendungan" type="text" class="form-control <?php $__errorArgs = ['panjang_puncak_tubuh_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="panjang_puncak_tubuh_bendungan" value="<?php echo e($data->panjang_puncak_tubuh_bendungan); ?>" required autocomplete="panjang_puncak_tubuh_bendungan">

                                <?php $__errorArgs = ['panjang_puncak_tubuh_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="tinggi_dari_sungai_tubuh_bendungan" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Tinggi Dari Sungai Tubuh Bendungan')); ?></label>

                            <div class="col-md-6">
                                <input id="tinggi_dari_sungai_tubuh_bendungan" type="text" class="form-control <?php $__errorArgs = ['tinggi_dari_sungai_tubuh_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tinggi_dari_sungai_tubuh_bendungan" value="<?php echo e($data->tinggi_dari_sungai_tubuh_bendungan); ?>" required autocomplete="tinggi_dari_sungai_tubuh_bendungan">

                                <?php $__errorArgs = ['tinggi_dari_sungai_tubuh_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="tinggi_dari_fondasi_tubuh_bendungan" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Tinggi Dari Fondasi Tubuh Bendungan')); ?></label>

                            <div class="col-md-6">
                                <input id="tinggi_dari_fondasi_tubuh_bendungan" type="text" class="form-control <?php $__errorArgs = ['tinggi_dari_fondasi_tubuh_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tinggi_dari_fondasi_tubuh_bendungan" value="<?php echo e($data->tinggi_dari_fondasi_tubuh_bendungan); ?>" required autocomplete="tinggi_dari_fondasi_tubuh_bendungan">

                                <?php $__errorArgs = ['tinggi_dari_fondasi_tubuh_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="lebar_puncak_tubuh_bendungan" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Lebar Puncak Tubuh Bendungan')); ?></label>

                            <div class="col-md-6">
                                <input id="lebar_puncak_tubuh_bendungan" type="text" class="form-control <?php $__errorArgs = ['lebar_puncak_tubuh_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="lebar_puncak_tubuh_bendungan" value="<?php echo e($data->lebar_puncak_tubuh_bendungan); ?>" required autocomplete="lebar_puncak_tubuh_bendungan">

                                <?php $__errorArgs = ['lebar_puncak_tubuh_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="elevasi_puncak_tubuh_bendungan" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Elevasi Puncak Tubuh Bendungan')); ?></label>

                            <div class="col-md-6">
                                <input id="elevasi_puncak_tubuh_bendungan" type="text" class="form-control <?php $__errorArgs = ['elevasi_puncak_tubuh_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="elevasi_puncak_tubuh_bendungan" value="<?php echo e($data->elevasi_puncak_tubuh_bendungan); ?>" required autocomplete="elevasi_puncak_tubuh_bendungan">

                                <?php $__errorArgs = ['elevasi_puncak_tubuh_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="daerah_tangkapan_tubuh_bendungan" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Daerah Tangkapan Tubuh Bendungan')); ?></label>

                            <div class="col-md-6">
                                <input id="daerah_tangkapan_tubuh_bendungan" type="text" class="form-control <?php $__errorArgs = ['daerah_tangkapan_tubuh_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="daerah_tangkapan_tubuh_bendungan" value="<?php echo e($data->daerah_tangkapan_tubuh_bendungan); ?>" required autocomplete="daerah_tangkapan_tubuh_bendungan">

                                <?php $__errorArgs = ['daerah_tangkapan_tubuh_bendungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="tipe_bangunan_pelimpah" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Tipe Bangunan Pelimpah')); ?></label>

                            <div class="col-md-6">
                                <input id="tipe_bangunan_pelimpah" type="text" class="form-control <?php $__errorArgs = ['tipe_bangunan_pelimpah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tipe_bangunan_pelimpah" value="<?php echo e($data->tipe_bangunan_pelimpah); ?>" required autocomplete="tipe_bangunan_pelimpah">

                                <?php $__errorArgs = ['tipe_bangunan_pelimpah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="lokasi_bangunan_pelimpah" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Lokasi Bangunan Pelimpah')); ?></label>

                            <div class="col-md-6">
                                <input id="lokasi_bangunan_pelimpah" type="text" class="form-control <?php $__errorArgs = ['lokasi_bangunan_pelimpah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="lokasi_bangunan_pelimpah" value="<?php echo e($data->lokasi_bangunan_pelimpah); ?>" required autocomplete="lokasi_bangunan_pelimpah">

                                <?php $__errorArgs = ['lokasi_bangunan_pelimpah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="lebar_bangunan_pelimpah" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Lebar Bangunan Pelimpah')); ?></label>

                            <div class="col-md-6">
                                <input id="lebar_bangunan_pelimpah" type="text" class="form-control <?php $__errorArgs = ['lebar_bangunan_pelimpah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="lebar_bangunan_pelimpah" value="<?php echo e($data->lebar_bangunan_pelimpah); ?>" required autocomplete="lebar_bangunan_pelimpah">
                                <?php $__errorArgs = ['lebar_bangunan_pelimpah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="elevasi_bangunan_pelimpah" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Elevasi Bangunan Pelimpah')); ?></label>

                            <div class="col-md-6">
                                <input id="elevasi_bangunan_pelimpah" type="text" class="form-control <?php $__errorArgs = ['elevasi_bangunan_pelimpah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="elevasi_bangunan_pelimpah" value="<?php echo e($data->elevasi_bangunan_pelimpah); ?>" required autocomplete="elevasi_bangunan_pelimpah">

                                <?php $__errorArgs = ['elevasi_bangunan_pelimpah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="debit_inflow_qin_bangunan_pelimpah" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Debit Inflow Qin Bangunan Pelimpah')); ?></label>

                            <div class="col-md-6">
                                <input id="debit_inflow_qin_bangunan_pelimpah" type="text" class="form-control <?php $__errorArgs = ['debit_inflow_qin_bangunan_pelimpah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="debit_inflow_qin_bangunan_pelimpah" value="<?php echo e($data->debit_inflow_qin_bangunan_pelimpah); ?>" required autocomplete="debit_inflow_qin_bangunan_pelimpah">

                                <?php $__errorArgs = ['debit_inflow_qin_bangunan_pelimpah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="debit_inflow_q1000_bangunan_pelimpah" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Debit Inflow Q1000 Bangunan Pelimpah')); ?></label>

                            <div class="col-md-6">
                                <input id="debit_inflow_q1000_bangunan_pelimpah" type="text" class="form-control <?php $__errorArgs = ['debit_inflow_q1000_bangunan_pelimpah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="debit_inflow_q1000_bangunan_pelimpah" value="<?php echo e($data->debit_inflow_q1000_bangunan_pelimpah); ?>" required autocomplete="debit_inflow_q1000_bangunan_pelimpah">

                                <?php $__errorArgs = ['debit_inflow_q1000_bangunan_pelimpah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="tipe_bangunan_pengambilan" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Tipe Bangunan Pengambilan')); ?></label>

                            <div class="col-md-6">
                                <input id="tipe_bangunan_pengambilan" type="text" class="form-control <?php $__errorArgs = ['tipe_bangunan_pengambilan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tipe_bangunan_pengambilan" value="<?php echo e($data->tipe_bangunan_pengambilan); ?>" required autocomplete="tipe_bangunan_pengambilan">

                                <?php $__errorArgs = ['tipe_bangunan_pengambilan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="lokasi_bangunan_pengambilan" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Lokasi Bangunan Pengambilan')); ?></label>

                            <div class="col-md-6">
                                <input id="lokasi_bangunan_pengambilan" type="text" class="form-control <?php $__errorArgs = ['lokasi_bangunan_pengambilan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="lokasi_bangunan_pengambilan" value="<?php echo e($data->lokasi_bangunan_pengambilan); ?>" required autocomplete="lokasi_bangunan_pengambilan">

                                <?php $__errorArgs = ['lokasi_bangunan_pengambilan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="saluran_hantar_bangunan_pengambilan" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Saluran Hantar Bangunan Pengambilan')); ?></label>

                            <div class="col-md-6">
                                <input id="saluran_hantar_bangunan_pengambilan" type="text" class="form-control <?php $__errorArgs = ['saluran_hantar_bangunan_pengambilan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="saluran_hantar_bangunan_pengambilan" value="<?php echo e($data->saluran_hantar_bangunan_pengambilan); ?>" required autocomplete="saluran_hantar_bangunan_pengambilan">

                                <?php $__errorArgs = ['saluran_hantar_bangunan_pengambilan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="diameter_terowongan_bangunan_pengambilan" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Diameter Terowongan Bangunan Pengambilan')); ?></label>

                            <div class="col-md-6">
                                <input id="diameter_terowongan_bangunan_pengambilan" type="text" class="form-control <?php $__errorArgs = ['diameter_terowongan_bangunan_pengambilan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="diameter_terowongan_bangunan_pengambilan" value="<?php echo e($data->diameter_terowongan_bangunan_pengambilan); ?>" required autocomplete="diameter_terowongan_bangunan_pengambilan">

                                <?php $__errorArgs = ['diameter_terowongan_bangunan_pengambilan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="kapasitas_max_bangunan_pengambilan" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Kapasitas Terowongan Bangunan Pengambilan')); ?></label>

                            <div class="col-md-6">
                                <input id="kapasitas_max_bangunan_pengambilan" type="text" class="form-control <?php $__errorArgs = ['kapasitas_max_bangunan_pengambilan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kapasitas_max_bangunan_pengambilan" value="<?php echo e($data->kapasitas_max_bangunan_pengambilan); ?>" required autocomplete="kapasitas_max_bangunan_pengambilan">
                                <?php $__errorArgs = ['kapasitas_max_bangunan_pengambilan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="elev_muka_air_waduk" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Elev Muka Air Waduk')); ?></label>

                            <div class="col-md-6">
                                <input id="elev_muka_air_waduk" type="text" class="form-control <?php $__errorArgs = ['elev_muka_air_waduk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="elev_muka_air_waduk" value="<?php echo e($data->elev_muka_air_waduk); ?>" required autocomplete="elev_muka_air_waduk">

                                <?php $__errorArgs = ['elev_muka_air_waduk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="kapasitas_waduk" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Kapasitas Waduk')); ?></label>

                            <div class="col-md-6">
                                <input id="kapasitas_waduk" type="text" class="form-control <?php $__errorArgs = ['kapasitas_waduk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kapasitas_waduk" value="<?php echo e($data->kapasitas_waduk); ?>" required autocomplete="kapasitas_waduk">

                                <?php $__errorArgs = ['kapasitas_waduk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="luas_genangan_waduk" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Luas Genangan Waduk')); ?></label>

                            <div class="col-md-6">
                                <input id="luas_genangan_waduk" type="text" class="form-control <?php $__errorArgs = ['luas_genangan_waduk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="luas_genangan_waduk" value="<?php echo e($data->luas_genangan_waduk); ?>" required autocomplete="luas_genangan_waduk">
                                <?php $__errorArgs = ['luas_genangan_waduk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Rubah Data')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PT_DEHAS\resources\views/edit/bendungan.blade.php ENDPATH**/ ?>