<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(('Register')); ?></div>

                <div class="card-body">
                    <form action="/user/store" method="post">

                        <?php echo csrf_field(); ?>

                        <div class="row mb-3">
                            <label for="name" class="col-md-4 col-form-label text-md-end"><?php echo e(('Nama')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="nama" required autocomplete="name" autofocus>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="username" class="col-md-4 col-form-label text-md-end"><?php echo e(('Username')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" required autocomplete="name" autofocus>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="username" class="col-md-4 col-form-label text-md-end"><?php echo e(('No HP')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="no_hp" value="<?php echo e(old('no_hp')); ?>" required autocomplete="name" autofocus>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="email" class="col-md-4 col-form-label text-md-end"><?php echo e(('Alamat Email')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password" class="col-md-4 col-form-label text-md-end"><?php echo e(('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required autocomplete="new-password">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="jabatan" class="col-md-4 col-form-label text-md-end"><?php echo e(('Jabatan')); ?></label>
                            <div class="col-md-6">
                                <select type="jabatan" class="form-control" name="jabatan" id="role">
                                    <option value="0">Operator</option>
                                    <option value="1">Admin</option>
                                    <option value="2">Atasan</option>
                                    <option value="3">BPPD</option>
                                    <option value="4">Umum</option>
                                    <option value="5">Balai</option>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Tambah')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PT_DEHAS\resources\views/register/register.blade.php ENDPATH**/ ?>