<?php $__env->startSection('content'); ?>
    <div class="container-fluid" id="container-wrapper">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Data Bendungan</h1>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="card mb-4">
                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                        <a class="btn btn-primary" href="/bendungan/tambah" style="float: left;"> + Tambah Data
                            Bendungan</a>
                    </div>
                    <div class="table-responsive p-3">
                        <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                            <thead class="thead-light">
                                <tr>
                                    <th>Nama Bendungan</th>
                                    <th>Lokasi Bendungan</th>
                                    <th>Nama Sungai</th>
                                    <th>koordinat Bendungan X</th>
                                    <th>Koordinat Bendungan Y</th>
                                    <th>Pengelola Bendungan</th>
                                    <th>Telpon Pengelola Bendungan</th>
                                    <th>Alamat Pengelola Bendungan</th>
                                    <th>Type Tubuh Bendungan</th>
                                    <th>Tinggi Bendungan diukur dari dasar sungai</th>
                                    <th>Panjang Puncak Tubuh Bendungan</th>
                                    <th>Tinggi Dari Fondasi Tubuh Bendungan</th>
                                    <th>Lebar Puncak Tubuh Bendungan</th>
                                    <th>Elevasi Puncak Tubuh Bendungan</th>
                                    <th>Daerah Tangkapan Tubuh Bendungan</th>
                                    <th>Tipe Bangunan Pelimpah</th>
                                    <th>Lokasi Bangunan Pelimpah</th>
                                    <th>Lebar Bangunan Pelimpah</th>
                                    <th>Elevasi Bangunan Pelimpah</th>
                                    <th>Debit Inflow Qin Bangunan Pelimpah</th>
                                    <th>Debit Inflow Q1000 Bangunan Pelimpah</th>
                                    <th>Tipe Bangunan Pengambilan</th>
                                    <th>Lokasi Bangunan Pengambilan</th>
                                    <th>Saluran Hantar Bangunan Pengambilan</th>
                                    <th>Diameter Hantar Bangunan Pengambilan</th>
                                    <th>Kapasitas Max Bangunan Pengambilan</th>
                                    <th>Elevation Muka Air Waduk</th>
                                    <th>Kapasitas Waduk</th>
                                    <th>Luas Genangan Waduk</th>
                                    <th>Dibuat Pada</th>
                                    <th>Dibuat Oleh</th>
                                    <th>Diuptade Pada</th>
                                    <th>Diupdate Oleh</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $i = 1;
                                ?>
                                <?php $__currentLoopData = $bendungan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($p->nama_bendungan); ?> </td>
                                        <td><?php echo e($p->lokasi_bendungan); ?> </td>
                                        <td><?php echo e($p->nama_sungai); ?> </td>
                                        <td><?php echo e($p->koordinat_bendungan_x); ?> </td>
                                        <td><?php echo e($p->koordinat_bendungan_y); ?> </td>
                                        <td><?php echo e($p->pengelola_bendungan); ?> </td>
                                        <td><?php echo e($p->telp_pengelola_bendungan); ?> </td>
                                        <td><?php echo e($p->alamat_pengelola_bendungan); ?> </td>
                                        <td><?php echo e($p->type_tubuh_bendungan); ?> </td>
                                        <td><?php echo e($p->panjang_puncak_tubuh_bendungan); ?> </td>
                                        <td><?php echo e($p->tinggi_dari_sungai_tubuh_bendungan); ?> </td>
                                        <td><?php echo e($p->tinggi_dari_fondasi_tubuh_bendungan); ?> </td>
                                        <td><?php echo e($p->lebar_puncak_tubuh_bendungan); ?> </td>
                                        <td><?php echo e($p->elevasi_puncak_tubuh_bendungan); ?> </td>
                                        <td><?php echo e($p->daerah_tangkapan_tubuh_bendungan); ?> </td>
                                        <td><?php echo e($p->tipe_bangunan_pelimpah); ?> </td>
                                        <td><?php echo e($p->lokasi_bangunan_pelimpah); ?> </td>
                                        <td><?php echo e($p->lebar_bangunan_pelimpah); ?> </td>
                                        <td><?php echo e($p->elevasi_bangunan_pelimpah); ?> </td>
                                        <td><?php echo e($p->debit_inflow_qin_bangunan_pelimpah); ?> </td>
                                        <td><?php echo e($p->debit_inflow_q1000_bangunan_pelimpah); ?> </td>
                                        <td><?php echo e($p->tipe_bangunan_pengambilan); ?> </td>
                                        <td><?php echo e($p->lokasi_bangunan_pengambilan); ?> </td>
                                        <td><?php echo e($p->saluran_hantar_bangunan_pengambilan); ?> </td>
                                        <td><?php echo e($p->diameter_terowongan_bangunan_pengambilan); ?> </td>
                                        <td><?php echo e($p->kapasitas_max_bangunan_pengambilan); ?> </td>
                                        <td><?php echo e($p->elev_muka_air_waduk); ?> </td>
                                        <td><?php echo e($p->kapasitas_waduk); ?> </td>
                                        <td><?php echo e($p->luas_genangan_waduk); ?> </td>
                                        <td><?php echo e($p->created_at); ?></td>
                                        <td><?php echo e($p->created_by); ?></td>
                                        <td><?php echo e($p->updated_at); ?></td>
                                        <td><?php echo e($p->updated_by); ?></td>
                                        <td>
                                            <div class="btn-group">
                                                <a class="btn btn-warning" title="Edit"
                                                    href="/bendungan/edit/<?php echo e(encrypt($p->id_bendungan)); ?>">
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                                <a class="btn btn-danger alert_notif" title="Hapus"
                                                    href="/bendungan/hapus/<?php echo e(encrypt($p->id_bendungan)); ?>">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PT_DEHAS\resources\views/master/bendungan.blade.php ENDPATH**/ ?>