<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Masukkan Ketinggian Muka Air</div>

                    <div class="card-body">
                        <form action="<?php echo e(url('transaksi/mukaair/proses')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="fungsi" value="Tambah">
                            <div class="row mb-3">
                                <label for="name" class="col-md-4 col-form-label text-md-end">Muka Air</label>
                                <div class="col-md-6">
                                    <select class="form-control select2" name="id_waduk" id="list_mukaair">
                                        <option value="">--Masukkan Muka Air--</option>
                                        <?php $__currentLoopData = $mukaair; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id_waduk); ?>">
                                                <?php echo e($item->muka_air); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <a class="btn btn-warning" type="reset" href="<?php echo e(url()->previous()); ?>">TUTUP</a>
                                    <button type="submit" class="btn btn-success">SIMPAN</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('tambahanjs'); ?>
    <script type="text/javascript">
        // $(document).ready(function() {
        //     $("#list_mukaair").select2({
        //         tags: true,
        //         maximumInputLength: 7
        //     });
        // });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PT_DEHAS\resources\views/transaksi/mukaair/tambah.blade.php ENDPATH**/ ?>