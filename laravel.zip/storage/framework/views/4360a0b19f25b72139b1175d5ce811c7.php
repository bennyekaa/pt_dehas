<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Tambah Status Waduk</div>

                    <div class="card-body">
                        <form action="<?php echo e(url('waduk/proses')); ?>" method="post">

                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="fungsi" value="Edit">
                            <input type="hidden" name="id_waduk" value="<?php echo e($riwayat_waduk->id_waduk); ?>">

                            <div class="row mb-3">
                                <label for="name" class="col-md-4 col-form-label text-md-end">Muka Air</label>
                                <div class="col-md-6">
                                    <input type="number" step="any" class="form-control" name="muka_air" placeholder="Masukkan Nilai Muka Air" required value="<?php echo e($riwayat_waduk->muka_air); ?>">
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label for="name" class="col-md-4 col-form-label text-md-end">Tinggi Air</label>
                                <div class="col-md-6">
                                    <input type="number" step="any" class="form-control" name="tinggi_air" placeholder="Masukkan Nilai Tinggi Air" required value="<?php echo e($riwayat_waduk->tinggi_air); ?>">
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label for="name" class="col-md-4 col-form-label text-md-end">Debit Keluar</label>
                                <div class="col-md-6">
                                    <input type="number" step="any" class="form-control" name="debit_keluar" placeholder="Masukkan Nilai Debit Keluar" required value="<?php echo e($riwayat_waduk->debit_keluar); ?>">
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label for="keterangan" class="col-md-4 col-form-label text-md-end">Keterangan</label>
                                <div class="col-md-6">
                                    <textarea name="keterangan" class="form-control" rows="3" placeholder="Masukkan Keterangan"><?php echo e($riwayat_waduk->keterangan); ?></textarea>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label for="name" class="col-md-4 col-form-label text-md-end">Status</label>
                                <div class="col-md-6">
                                    <select class="form-control select2" name="status" required>
                                        <option value="">--Masukkan Status--</option>
                                            <option value="0" <?php if($riwayat_waduk->status == 0): ?> <?php echo e('selected'); ?> <?php endif; ?>>Normal</option>
                                            <option value="1" <?php if($riwayat_waduk->status == 1): ?> <?php echo e('selected'); ?> <?php endif; ?>>Waspada 1</option>
                                            <option value="2" <?php if($riwayat_waduk->status == 2): ?> <?php echo e('selected'); ?> <?php endif; ?>>Waspada 2</option>
                                            <option value="3" <?php if($riwayat_waduk->status == 3): ?> <?php echo e('selected'); ?> <?php endif; ?>>Siaga</option>
                                            <option value="4" <?php if($riwayat_waduk->status == 4): ?> <?php echo e('selected'); ?> <?php endif; ?>>Awas</option>
                                            <option value="5" <?php if($riwayat_waduk->status == 5): ?> <?php echo e('selected'); ?> <?php endif; ?>>Bahaya</option>
                                    </select>
                                </div>
                            </div>

                            <div class="row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <a class="btn btn-warning" type="reset" href="<?php echo e(url()->previous()); ?>">TUTUP</a>
                                    <button type="submit" class="btn btn-success">SIMPAN</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PT_DEHAS\resources\views/master/waduk/edit.blade.php ENDPATH**/ ?>