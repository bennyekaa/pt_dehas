<?php
return array(
    'token' => 'pk.eyJ1IjoiYmVubnlla2FhIiwiYSI6ImNsZzA5N2tvazBtbTIzb210ajhuOXA0Z2UifQ.PvEFAsFqPnqKxjAScY7m6g'
);
