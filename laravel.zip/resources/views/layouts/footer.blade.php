      <!-- Footer -->
      <footer class="sticky-footer bg-white">
          <div class="container my-auto">
              <div class="copyright text-center my-auto">
                  <span>copyright &copy;
                      <script>
                          document.write(new Date().getFullYear());
                      </script> - developed by
                      <b><a href="https://wa.link/fdl86f" target="_blank">DoIT</a></b>
                  </span>
              </div>
          </div>
      </footer>
      <!-- Footer -->

